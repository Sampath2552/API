package com.example.airfowgt.controller;

import com.example.airfowgt.dto.DagResponse;
import com.example.airfowgt.dto.DagRunRequest;
import com.example.airfowgt.dto.DagRunResponse;
import com.example.airfowgt.dto.XComResponse;
import com.example.airfowgt.service.AirflowService;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.Map;

@RestController
@RequestMapping("/airflow")
@RequiredArgsConstructor
public class AirflowController {

    private final AirflowService airflowService;

    @PostMapping("/trigger/{dagId}")
    public Mono<DagRunResponse> trigger(
            @PathVariable String dagId,
            @RequestBody DagRunRequest request
    ) {
        return airflowService.triggerDag(dagId, request);
    }

    @GetMapping("/dag/{dagId}")
    public Mono<DagResponse> getDag(@PathVariable String dagId) {
        return airflowService.getDag(dagId);
    }

    @GetMapping("/dag/{dagId}/runs")
    public Mono<JsonNode> dagRuns(@PathVariable String dagId) {
        return airflowService.getDagRuns(dagId);
    }

    @GetMapping("/health")
    public Mono<Map<String, Object>> health() {
        return airflowService.health();
    }

    @GetMapping("/xcom")
    public Mono<XComResponse> xcom(
            @RequestParam String dagId,
            @RequestParam String dagRunId,
            @RequestParam String taskId,
            @RequestParam String key
    ) {
        return airflowService.getXCom(dagId, dagRunId, taskId, key);
    }
}

