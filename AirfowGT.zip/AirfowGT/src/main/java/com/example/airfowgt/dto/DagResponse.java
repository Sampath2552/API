package com.example.airfowgt.dto;

import lombok.Data;

@Data
public class DagResponse {
    private String dagId;
    private boolean isPaused;
    private String fileloc;
}
