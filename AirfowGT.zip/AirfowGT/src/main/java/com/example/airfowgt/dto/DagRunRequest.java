package com.example.airfowgt.dto;

import lombok.Data;

import java.util.Map;

@Data
public class DagRunRequest {
    private String dagRunId;
    private Map<String, Object> conf;
}
