package com.example.airfowgt.dto;

import lombok.Data;

@Data
public class DagRunResponse {
    private String dagId;
    private String dagRunId;
    private String state;
    private String logicalDate;
}
