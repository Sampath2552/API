package com.example.airfowgt.dto;

import lombok.Data;

@Data
public class XComResponse {
    private String key;
    private Object value;
}

