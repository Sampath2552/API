package com.example.airfowgt.service;

import com.example.airfowgt.config.AirflowProperties;
import com.example.airfowgt.dto.AirflowTokenResponse;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class AirflowAuthService {


    private final WebClient airflowAuthClient;


    private final AirflowProperties props;

    private String token;

    public Mono<String> getToken() {
        if (token != null) {
            return Mono.just(token);
        }

        return airflowAuthClient.post()
                .uri("/auth/token")
                .bodyValue(Map.of(
                        "username", "airflow",
                        "password", "airflow"
                ))
                .retrieve()
                .bodyToMono(AirflowTokenResponse.class)
                .map(resp -> {
                    this.token = resp.getAccessToken();
                    return resp.getAccessToken();
                });
    }
}
