package com.example.airfowgt.service;

import com.example.airfowgt.dto.DagResponse;
import com.example.airfowgt.dto.DagRunRequest;
import com.example.airfowgt.dto.DagRunResponse;
import com.example.airfowgt.dto.XComResponse;
import com.fasterxml.jackson.databind.JsonNode;
import reactor.core.publisher.Mono;

import java.util.Map;

public interface AirflowService {

    Mono<DagRunResponse> triggerDag(String dagId, DagRunRequest request);

    Mono<DagResponse> getDag(String dagId);

    Mono<JsonNode> getDagRuns(String dagId);

    Mono<Map<String, Object>> health();

    Mono<XComResponse> getXCom(
            String dagId,
            String dagRunId,
            String taskId,
            String key
    );
}
