package com.example.airfowgt.service;

import com.example.airfowgt.dto.DagResponse;
import com.example.airfowgt.dto.DagRunRequest;
import com.example.airfowgt.dto.DagRunResponse;
import com.example.airfowgt.dto.XComResponse;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

@Service
@RequiredArgsConstructor
public class AirflowServiceImpl implements AirflowService {

    private final WebClient airflowApiClient;
    private final AirflowAuthService authService;

    private <T> Mono<T> authorizedGet(String uri, Class<T> clazz) {
        return authService.getToken()
                .flatMap(token ->
                        airflowApiClient.get()
                                .uri(uri)
                                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                                .retrieve()
                                .bodyToMono(clazz)
                );
    }

    private <T> Mono<T> authorizedPost(String uri, Object body, Class<T> clazz) {
        return authService.getToken()
                .flatMap(token ->
                        airflowApiClient.post()
                                .uri(uri)
                                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                                .bodyValue(body)
                                .retrieve()
                                .bodyToMono(clazz)
                );
    }

    @Override
    public Mono<DagRunResponse> triggerDag(String dagId, DagRunRequest request) {
        return authorizedPost(
                "/dags/" + dagId + "/dagRuns",
                request,
                DagRunResponse.class
        );
    }

    @Override
    public Mono<DagResponse> getDag(String dagId) {
        return authorizedGet("/dags/" + dagId, DagResponse.class);
    }

    @Override
    public Mono<JsonNode> getDagRuns(String dagId) {
        return authorizedGet("/dags/" + dagId + "/dagRuns", JsonNode.class);
    }

    @Override
    public Mono<Map<String, Object>> health() {
        return authService.getToken()
                .flatMap(token ->
                        airflowApiClient.get()
                                .uri("/monitor/health")
                                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                                .retrieve()
                                .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {})
                );
    }


    @Override
    public Mono<XComResponse> getXCom(
            String dagId,
            String dagRunId,
            String taskId,
            String key
    ) {
        String uri = String.format(
                "/dags/%s/dagRuns/%s/taskInstances/%s/xcomEntries/%s",
                dagId, dagRunId, taskId, key
        );
        return authorizedGet(uri, XComResponse.class);
    }
}

